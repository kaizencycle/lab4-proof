import json, os
from pathlib import Path
from datetime import datetime
from .hashing import sha256_json

DATA_DIR = Path(os.environ.get("LEDGER_PATH", "data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

def _path(name: str) -> Path:
    return DATA_DIR / name

def append_jsonl(filename: str, record: dict) -> str:
    p = _path(filename)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    return sha256_json(record)

def write_json(filename: str, obj: dict) -> str:
    p = _path(filename)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    return sha256_json(obj)

def today_files(date_str: str):
    seed_file  = f"{date_str}/{date_str}.seed.json"
    echo_file  = f"{date_str}/{date_str}.echo.jsonl"
    seal_file  = f"{date_str}/{date_str}.seal.json"
    return seed_file, echo_file, seal_file