import hashlib, json

def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def sha256_json(obj) -> str:
    # canonical JSON so hashes are stable
    blob = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return sha256_bytes(blob.encode("utf-8"))

def merkle_root(leaves_hex: list[str]) -> str:
    """
    leaves_hex: list of *hex* SHA-256 digests in order.
    Returns the hex Merkle root. If list is empty, return sha256 of empty bytes.
    """
    if not leaves_hex:
        return sha256_bytes(b"")
    layer = [bytes.fromhex(h) for h in leaves_hex]
    while len(layer) > 1:
        nxt = []
        for i in range(0, len(layer), 2):
            a = layer[i]
            b = layer[i + 1] if i + 1 < len(layer) else a  # duplicate last if odd
            nxt.append(hashlib.sha256(a + b).digest())
        layer = nxt
    return layer[0].hex()

