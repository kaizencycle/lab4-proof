from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from datetime import datetime
import os, json, io, zipfile, hmac, hashlib, pathlib
from typing import List, Optional
from .models import Seed, Sweep, Seal
from .storage import append_jsonl, write_json, today_files
from .hashing import sha256_json, merkle_root
import io, zipfile, pathlib, datetime
from fastapi.responses import FileResponse


print(">>> MAIN.PY LIVE FROM:", __file__)

app = FastAPI(title="HIVE-PAW API (with ledger)", version="0.1.2")

PROJECT_ROOT = pathlib.Path(__file__).resolve().parents[1]  # .../lab4-proof
BACKUPS_DIR   = PROJECT_ROOT / "backups"
BACKUPS_DIR.mkdir(parents=True, exist_ok=True)

def _make_backup_zip() -> pathlib.Path:
    ts = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    out_path = BACKUPS_DIR / f"lab4_proof_{ts}.zip"
    app_dir = PROJECT_ROOT / "app"
    req_txt = PROJECT_ROOT / "requirements.txt"

    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in app_dir.glob("*"):
            if p.is_file():
                zf.write(p, arcname=f"app/{p.name}")
        if req_txt.exists():
            zf.write(req_txt, arcname="requirements.txt")
    return out_path

DATA_DIR = pathlib.Path("data")

def _list_days() -> List[str]:
    if not DATA_DIR.exists(): return []
    days = []
    for p in DATA_DIR.iterdir():
        if p.is_dir() and len(p.name) == 10 and p.name[4] == "-" and p.name[7] == "-":
            days.append(p.name)
    days.sort()
    return days

def _latest_day() -> Optional[str]:
    d = _list_days()
    return d[-1] if d else None

def _compute_day_root(date: str) -> dict:
    data_dir = pathlib.Path("data") / date
    seed_p = data_dir / f"{date}.seed.json"
    echo_p = data_dir / f"{date}.echo.jsonl"
    seal_p = data_dir / f"{date}.seal.json"

    leaves, counts = [], {"seed": 0, "sweeps": 0, "seal": 0}

    if seed_p.exists():
        with seed_p.open("r", encoding="utf-8") as f:
            leaves.append(sha256_json(json.load(f)))
            counts["seed"] = 1

    if echo_p.exists():
        with echo_p.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line: continue
                try:
                    leaves.append(sha256_json(json.loads(line)))
                    counts["sweeps"] += 1
                except Exception:
                    continue

    if seal_p.exists():
        with seal_p.open("r", encoding="utf-8") as f:
            leaves.append(sha256_json(json.load(f)))
            counts["seal"] = 1

    return {"root": merkle_root(leaves), "leaves": leaves, "counts": counts}

def _hmac_sign(obj: dict) -> Optional[str]:
    key = os.environ.get("LEDGER_HMAC_KEY")
    if not key: return None
    blob = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hmac.new(key.encode("utf-8"), blob, hashlib.sha256).hexdigest()


# ------------------ sanity routes ------------------
@app.get("/health")
def health():
    return {"ok": True, "ts": datetime.utcnow().isoformat() + "Z"}

@app.get("/ping")
def ping():
    return {"pong": True}

@app.get("/routes")
def routes():
    return [{"path": r.path, "methods": list(getattr(r, "methods", []))}
            for r in app.router.routes]

# ------------------ write endpoints ----------------
@app.post("/seed")
def seed(payload: Seed):
    seed_file, _, _ = today_files(payload.date)
    record = {
        "type": "seed",
        "date": payload.date,
        "time": payload.time,
        "intent": payload.intent,
        "meta": payload.meta or {},
        "ts": datetime.utcnow().isoformat() + "Z",
    }
    h = write_json(seed_file, record)
    return {"seed_hash": h, "file": seed_file}

@app.post("/sweep")
def sweep(payload: Sweep):
    date_str = datetime.now().strftime("%Y-%m-%d")
    _, echo_file, _ = today_files(date_str)
    record = {
        "type": "sweep",
        "date": date_str,
        "chamber": payload.chamber,
        "note": payload.note,
        "meta": payload.meta or {},
        "ts": datetime.utcnow().isoformat() + "Z",
    }
    att = append_jsonl(echo_file, record)
    return {"attestation": att, "file": echo_file}

@app.post("/seal")
def seal(payload: Seal):
    seed_file, echo_file, seal_file = today_files(payload.date)
    record = {
        "type": "seal",
        "date": payload.date,
        "wins": payload.wins,
        "blocks": payload.blocks,
        "tomorrow_intent": payload.tomorrow_intent,
        "ts": datetime.utcnow().isoformat() + "Z",
        "links": {"seed": seed_file, "echo": echo_file},
    }
    # write preliminary seal
    write_json(seal_file, record)

    # compute day root
    mr = _compute_day_root(payload.date)
    record["day_root"] = mr["root"]

    # optional HMAC signature
    sig = _hmac_sign(record)
    if sig:
        record["signature"] = {"algo": "HMAC-SHA256", "key_id": "LEDGER_HMAC_KEY", "value": sig}

    # write final sealed record
    write_json(seal_file, record)

    return {
        "seal_hash": sha256_json(record),
        "day_root": mr["root"],
        "counts": mr["counts"],
        "signature": record.get("signature"),
        "file": seal_file,
    }

# NEW: compute daily merkle over seed + sweeps + seal
    mr = _compute_day_root(payload.date)
    return {"seal_hash": h, "day_root": mr["root"], "counts": mr["counts"], "file": seal_file}
    return {"seal_hash": h, "file": seal_file}

# ------------------ READ endpoint (the ledger) -----
@app.get("/ledger/{date}")
def get_ledger(date: str):
    """Return the full day bundle: seed + sweeps + seal."""
    seed_path = os.path.join("data", f"{date}/{date}.seed.json")
    echo_path = os.path.join("data", f"{date}/{date}.echo.jsonl")
    seal_path = os.path.join("data", f"{date}/{date}.seal.json")

    result = {"date": date, "seed": None, "sweeps": [], "seal": None}

    if os.path.exists(seed_path):
        with open(seed_path, "r", encoding="utf-8") as f:
            result["seed"] = json.load(f)

    if os.path.exists(echo_path):
        with open(echo_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    result["sweeps"].append(json.loads(line))

    if os.path.exists(seal_path):
        with open(seal_path, "r", encoding="utf-8") as f:
            result["seal"] = json.load(f)

    if not result["seed"] and not result["seal"]:
        raise HTTPException(status_code=404, detail="No ledger found for this date")

# NEW: add daily Merkle root
    mr = _compute_day_root(date)
    result["day_root"] = mr["root"]
    result["merkle_meta"] = mr["counts"]  # small counts summary

    return result

@app.get("/index")
def index():
    return {"days": _list_days()}

@app.get("/ledger/latest")
def ledger_latest():
    day = _latest_day()
    if not day:
        raise HTTPException(status_code=404, detail="No ledger days found")
    return get_ledger(day)

@app.get("/verify/{date}")
def verify(date: str):
    seal_path = os.path.join("data", f"{date}/{date}.seal.json")
    mr = _compute_day_root(date)
    expected = mr["root"]

    stored = None
    signature_ok = None
    if os.path.exists(seal_path):
        try:
            with open(seal_path, "r", encoding="utf-8") as f:
                seal_json = json.load(f)
                stored = seal_json.get("day_root")
                sig = seal_json.get("signature", {})
                if sig and sig.get("algo") == "HMAC-SHA256":
                    # recompute signature over record-without-signature
                    clean = {k: seal_json[k] for k in seal_json if k != "signature"}
                    signature_ok = (_hmac_sign(clean) == sig.get("value"))
        except Exception:
            pass

    ok = (stored == expected) and (stored is not None)
    return {"date": date, "ok": ok, "expected": expected, "stored": stored,
            "counts": mr["counts"], "signature_ok": signature_ok}

@app.get("/export/{date}")
def export_day(date: str):
    base = os.path.join("data", date)
    seed_path = os.path.join(base, f"{date}.seed.json")
    echo_path = os.path.join(base, f"{date}.echo.jsonl")
    seal_path = os.path.join(base, f"{date}.seal.json")

    manifest = {
        "date": date,
        "day_root": mr["root"],
        "counts": mr["counts"],
        "files": {
            "seed": f"{date}.seed.json" if os.path.exists(seed_path) else None,
            "echo": f"{date}.echo.jsonl" if os.path.exists(echo_path) else None,
            "seal": f"{date}.seal.json" if os.path.exists(seal_path) else None,
        },
    }

    mem = io.BytesIO()
    with zipfile.ZipFile(mem, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        if os.path.exists(seed_path): zf.write(seed_path, arcname=f"{date}.seed.json")
        if os.path.exists(echo_path): zf.write(echo_path, arcname=f"{date}.echo.jsonl")
        if os.path.exists(seal_path): zf.write(seal_path, arcname=f"{date}.seal.json")
        zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    mem.seek(0)

    return FileResponse(mem, media_type="application/zip", filename=f"ledger-{date}.zip")

@app.get("/ledger/{date}/view", response_class=HTMLResponse)
def ledger_view(date: str):
    try:
        bundle = get_ledger(date)
    except HTTPException as e:
        return HTMLResponse(f"<h1>{date}</h1><p>{e.detail}</p>", status_code=e.status_code)

    seed = bundle.get("seed")
    sweeps = bundle.get("sweeps", [])
    seal = bundle.get("seal")
    day_root = bundle.get("day_root")

    def esc(t): return (t or "").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")

    html = [
        "<!doctype html><meta charset='utf-8'>",
        f"<title>Ledger {date}</title>",
        "<style>body{font-family:system-ui;margin:24px} .card{border:1px solid #ddd;border-radius:8px;padding:12px;margin:12px 0} .meta{color:#666;font-size:12px} code{background:#f6f8fa;padding:2px 4px;border-radius:4px}</style>",
        f"<h1>Ledger — {esc(date)}</h1>",
        f"<p><b>Merkle root</b>: <code>{esc(day_root)}</code></p>",
    ]
    if seed:
        html += ["<div class='card'>","<h3>Seed</h3>",
                 f"<div class='meta'>{esc(seed.get('time',''))} · ts {esc(seed.get('ts',''))}</div>",
                 f"<p><b>Intent:</b> {esc(seed.get('intent',''))}</p>","</div>"]
    if sweeps:
        html.append("<h3>Sweeps</h3>")
        for i, s in enumerate(sweeps, 1):
            html += ["<div class='card'>",
                     f"<div class='meta'>#{i} · {esc(s.get('ts',''))}</div>",
                     f"<p><b>Chamber:</b> {esc(s.get('chamber',''))}</p>",
                     f"<p><b>Note:</b> {esc(s.get('note',''))}</p>",
                     "</div>"]
    if seal:
        html += ["<div class='card'>","<h3>Seal</h3>",
                 f"<div class='meta'>ts {esc(seal.get('ts',''))}</div>",
                 f"<p><b>Wins:</b> {esc(seal.get('wins',''))}</p>",
                 f"<p><b>Blocks:</b> {esc(seal.get('blocks',''))}</p>",
                 f"<p><b>Tomorrow:</b> {esc(seal.get('tomorrow_intent',''))}</p>",
                 "</div>"]
    html += ["<hr>", f"<p><a href='/export/{esc(date)}'>Download archive (.zip)</a></p>", "</body></html>"]
    return HTMLResponse("".join(html))
@app.post("/backup-now")
def backup_now():
    z = _make_backup_zip()
    # return metadata and a path you can use in Explorer
    return {"ok": True, "backup": str(z), "bytes": z.stat().st_size}





