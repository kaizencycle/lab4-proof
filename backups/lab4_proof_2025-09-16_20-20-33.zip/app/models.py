from pydantic import BaseModel
from typing import Optional, Dict, Any

class Seed(BaseModel):
    date: str
    time: str
    intent: str
    meta: Optional[Dict[str, Any]] = None

class Sweep(BaseModel):
    chamber: str
    note: Optional[str] = None
    meta: Optional[Dict[str, Any]] = None

class Seal(BaseModel):
    date: str
    wins: str
    blocks: str
    tomorrow_intent: str
    meta: Optional[Dict[str, Any]] = None